resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

files {
    's_m_m_paramedic_01.ydd',
    's_m_m_paramedic_01.yft',
    's_m_m_paramedic_01.ymt',
    's_m_m_paramedic_01.ytd',
}